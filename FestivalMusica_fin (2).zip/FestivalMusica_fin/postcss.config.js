module.exports = {
    plugins: {
        "autoprefixer": true
    }
}